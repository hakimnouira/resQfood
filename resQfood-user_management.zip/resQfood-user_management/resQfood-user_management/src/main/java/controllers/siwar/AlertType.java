package controllers.siwar;

public enum AlertType {
    ERROR,
    INFORMATION
}
