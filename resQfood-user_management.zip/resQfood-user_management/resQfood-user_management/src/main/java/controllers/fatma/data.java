package controllers.fatma;

public class data {
    public static String path;
}
