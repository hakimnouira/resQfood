package controllers;

import models.feriel.User;

public abstract class Controller {
    public void initSelectedUser(User user) {

    }
}
