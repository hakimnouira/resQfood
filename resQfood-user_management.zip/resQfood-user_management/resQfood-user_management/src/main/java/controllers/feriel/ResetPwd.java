package controllers.feriel;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class ResetPwd {

    @FXML
    private TextField newpwdTf;

    @FXML
    void cancel(ActionEvent event) {

    }

    @FXML
    void confirmNewPwd(ActionEvent event) {

    }

}
