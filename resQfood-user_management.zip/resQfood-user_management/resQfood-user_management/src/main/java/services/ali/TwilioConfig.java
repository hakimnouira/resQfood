package services.ali;

public class TwilioConfig {
    public static final String ACCOUNT_SID = "AC720bca4527d61fc3732d4f06705cda6d";
    public static final String AUTH_TOKEN = "b4a4f61d8b5d51b7aee4bba79ac0f930";
    public static final String TWILIO_PHONE_NUMBER = "+19202828176";
}
