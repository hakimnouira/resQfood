package services.fatma;

import models.fatma.Participations;

import java.sql.SQLException;
import java.util.List;

public interface IServiceP {


    void addParticipation(int id_event, String particip_name) throws SQLException;

    List<Participations> read() throws SQLException;
}

